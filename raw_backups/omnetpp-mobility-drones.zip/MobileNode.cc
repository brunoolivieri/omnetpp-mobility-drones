#include "MobileNode.h"
namespace inet {

//Register_Class(MobileNode);
Define_Module(MobileNode);

void MobileNode::initialize(int stage) {
  // an example of reading new parameter in the first stage
  if (stage == INITSTAGE_LOCAL) {
     EV << "par1 = " << par("par1").intValue() << endl;
  }
  // your code
}

void MobileNode::handleMessage(cMessage *msg) {
     // your code

}

} //namespace
